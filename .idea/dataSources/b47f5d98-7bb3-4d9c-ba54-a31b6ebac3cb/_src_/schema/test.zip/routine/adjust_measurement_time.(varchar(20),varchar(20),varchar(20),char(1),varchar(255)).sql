CREATE FUNCTION adjust_measurement_time(fiscal_period VARCHAR(20), unit VARCHAR(20), unit_option VARCHAR(20),
                                        need_fix_hole CHAR, value VARCHAR(255))
  RETURNS VARCHAR(255)
  BEGIN
    DECLARE res VARCHAR(255) DEFAULT NULL;

    IF value IS NULL THEN RETURN NULL; END IF;
    IF LENGTH(value) < 10 THEN RETURN value; END IF;
    IF fiscal_period > '' THEN
        CASE unit
            WHEN 'day' THEN
                IF 'weekday' = fiscal_period THEN
                    SELECT MAX(calendar_date) INTO res FROM weekday WHERE calendar_date = DATE(value);
                    IF res IS NULL AND 'Y' = need_fix_hole THEN
                        SELECT MIN(calendar_date) INTO res FROM weekday WHERE calendar_date >= DATE(value);
                    END IF;
                ELSE
                    SELECT concat(left(value, 10), ' 00:00:00') INTO res;
                END IF;
            WHEN 'month' THEN SELECT MAX(first_day_of_period) INTO res FROM fiscal_month WHERE value BETWEEN first_day_of_period AND DATE_ADD(last_day_of_period, INTERVAL 86399 SECOND) LIMIT 1;
            WHEN 'quarter' THEN SELECT MAX(first_day_of_quarter) INTO res FROM fiscal_quarter WHERE value BETWEEN first_day_of_quarter AND DATE_ADD(last_day_of_quarter, INTERVAL 86399 SECOND) LIMIT 1;
            WHEN 'year' THEN SELECT MAX(first_day_of_fiscal_year) INTO res FROM fiscal_year WHERE value BETWEEN first_day_of_fiscal_year AND DATE_ADD(last_day_of_fiscal_year, INTERVAL 86399 SECOND) LIMIT 1;
            ELSE SELECT concat(left(value, 10), ' 00:00:00') INTO res;
        END CASE;
    ELSE
        CASE unit
            WHEN 'minute' THEN SELECT concat(left(value, 16), ':00') INTO res;
            WHEN 'hour' THEN SELECT concat(left(value, 13), ':00:00') INTO res;
            WHEN 'day' THEN SELECT concat(left(value, 10), ' 00:00:00') INTO res;
            WHEN 'week' THEN SELECT CONCAT(IF (unit_option = 'start of week', first_day_of_week, last_day_of_week), ' 00:00:00') INTO res FROM calendar_week WHERE value BETWEEN first_day_of_week AND DATE_ADD(last_day_of_week, INTERVAL 86399 SECOND) LIMIT 1;
            WHEN 'month' THEN SELECT concat(left(value, 7), '-01 00:00:00') INTO res;
            WHEN 'quarter' THEN SELECT concat(year(value), '-', lpad((quarter(value)-1) * 3 + 1, 2, '0'), '-01 00:00:00') INTO res;
            WHEN 'year' THEN SELECT concat(left(value, 4), '-01-01 00:00:00') INTO res;
            ELSE SELECT NULL INTO res;
        END CASE;
    END IF;

    RETURN res;
END;
