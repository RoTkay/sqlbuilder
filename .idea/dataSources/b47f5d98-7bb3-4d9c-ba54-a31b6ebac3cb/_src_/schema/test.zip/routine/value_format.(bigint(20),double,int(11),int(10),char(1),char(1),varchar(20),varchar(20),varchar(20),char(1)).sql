CREATE FUNCTION value_format(p_value_int BIGINT, p_value_float DOUBLE, p_display_mask_id INT, p_decimals INT(10),
                             p_dec_point CHAR, p_thousands_sep CHAR, p_show_amount_as VARCHAR(20), p_prefix VARCHAR(20),
                             p_suffix    VARCHAR(20), p_currency_mask_ind CHAR)
  RETURNS VARCHAR(50)
  BEGIN
    DECLARE res VARCHAR(255);
    DECLARE p_number DOUBLE;

    SET p_number = IFNULL(p_value_int,p_value_float);

    IF (p_display_mask_id IS NOT NULL) THEN
        
        CASE p_show_amount_as
            WHEN 'Thousands' THEN SET p_number = p_number / 1000;
            WHEN 'Millions' THEN SET p_number = p_number / 1000000;
            WHEN 'Hundredths' THEN SET p_number = p_number * 100;
            WHEN 'Percent' THEN SET p_number = p_number * 100;
            ELSE BEGIN END;
        END CASE;

        IF p_decimals IS NULL THEN SET res = FORMAT(p_number, 0); END IF;
        IF p_decimals = 0 THEN SET res = FORMAT(p_number, 0); END IF;
        IF p_decimals = 1 THEN SET res = FORMAT(p_number, 1); END IF;
        IF p_decimals = 2 THEN SET res = FORMAT(p_number, 2); END IF;
        IF p_decimals = 3 THEN SET res = FORMAT(p_number, 3); END IF;
        IF p_decimals = 4 THEN SET res = FORMAT(p_number, 4); END IF;
        IF p_decimals = 5 THEN SET res = FORMAT(p_number, 5); END IF;
        IF p_decimals = 6 THEN SET res = FORMAT(p_number, 6); END IF;
        IF p_decimals = 7 THEN SET res = FORMAT(p_number, 7); END IF;
        IF p_decimals = 8 THEN SET res = FORMAT(p_number, 8); END IF;

    ELSE
        SET p_prefix = IF (p_prefix IS NOT NULL, p_prefix, IF(p_currency_mask_ind='Y' AND @DEFAULT_CURRENCY_PREFIX IS NOT NULL,@DEFAULT_CURRENCY_PREFIX,''));

        IF (ABS(p_number)>1000000) THEN
            SET p_suffix = IFNULL(@METRIC_MILLIONS_DISPLAY_SUFFIX,'M');
            SET p_number=p_number/1000000;
        END IF;

        IF (p_number>=100 OR (ABS(p_number-FLOOR(p_number))<0.00001)) THEN
            SET res = FORMAT(p_number, 0);
        ELSE
            IF (p_value_int IS NULL OR ABS(p_value_int)>1000000) THEN
                IF (ABS(p_number)>=10) THEN
                    SET res = FORMAT(p_number, 1);
                ELSE
                    SET res = FORMAT(p_number, 2);
                END IF;
            ELSE
                IF (ABS(p_number)<0.0001) THEN
                    SET res = FORMAT(p_number, 5);
                ELSEIF (ABS(p_number)<0.001) THEN
                    SET res = FORMAT(p_number, 4);
                ELSEIF (ABS(p_number)<0.01) THEN
                    SET res = FORMAT(p_number, 3);
                ELSEIF (ABS(p_number-FLOOR(p_number))>0.00001) THEN
                    RETURN CONCAT(IFNULL(p_prefix,''), p_value_float, IFNULL(p_suffix,''));
                ELSEIF(p_value_int IS NULL) THEN
                    SET res = FORMAT(p_number, 2);
                ELSE
                    SET res = FORMAT(p_number, 0);
                END IF;
            END IF;
        END IF;

        SET p_thousands_sep = IFNULL(@METRIC_DEFAULT_THOUSANDS_DELIMITER,',');

    END IF;

    SET res = REPLACE(res, '.', 'd');
    SET res = REPLACE(res, ',', IF(p_thousands_sep IS NOT NULL,p_thousands_sep,','));
    SET res = REPLACE(res, 'd', IF(p_dec_point IS NOT NULL,p_dec_point,'.'));
    RETURN CONCAT(IFNULL(p_prefix,''), res, IF(p_suffix IS NOT NULL,p_suffix,''));

END;
