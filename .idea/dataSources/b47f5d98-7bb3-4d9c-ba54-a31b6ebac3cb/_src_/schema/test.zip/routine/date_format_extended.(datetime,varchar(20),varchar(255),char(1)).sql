CREATE FUNCTION date_format_extended(p_date             DATETIME, p_fiscal_period_type VARCHAR(20),
                                     p_format           VARCHAR(255), p_xtd_interval_ind CHAR)
  RETURNS VARCHAR(255)
  BEGIN
    DECLARE res VARCHAR(255);

    IF p_date IS NULL OR p_date = 0 THEN RETURN ''; END IF;

    IF p_xtd_interval_ind != 'Y' AND p_fiscal_period_type > '' AND p_fiscal_period_type != 'weekday' THEN
        CASE p_fiscal_period_type
            WHEN 'month' THEN SELECT IFNULL(MAX(name), '') INTO res FROM fiscal_month WHERE p_date BETWEEN first_day_of_period AND DATE_ADD(last_day_of_period, INTERVAL 86399 SECOND);
            WHEN 'quarter' THEN SELECT IFNULL(MAX(name), '') INTO res FROM fiscal_quarter WHERE p_date BETWEEN first_day_of_quarter AND DATE_ADD(last_day_of_quarter, INTERVAL 86399 SECOND);
            WHEN 'year' THEN SELECT IFNULL(MAX(name), '') INTO res FROM fiscal_year WHERE p_date BETWEEN first_day_of_fiscal_year AND DATE_ADD(last_day_of_fiscal_year, INTERVAL 86399 SECOND);
            ELSE SELECT NULL INTO res;
        END CASE;
        RETURN res;
    ELSE
        SET p_format = REPLACE(p_format, '%Q', CONCAT('Q', QUARTER(p_date)));
        RETURN DATE_FORMAT(p_date, p_format);
    END IF;
END;
